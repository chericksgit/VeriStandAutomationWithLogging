#Import the next elements to be able to create a logging specification
import clr
clr.AddReference("NationalInstruments.VeriStand.ClientAPI")
from NationalInstruments.VeriStand.ClientAPI import Factory
from NationalInstruments.VeriStand.ClientAPI import Logging
from NationalInstruments.VeriStand.ClientAPI.Logging import *
from System import Array

class Logging_Spec_File:
    #Internal attributes
    channels_list = []      #channels_list will be a list of dictionaries
    custom_rate = 0
    
    def __init__(self,log_spec_path):
        #Parse XML and go to section of interest LoggingConfigurationModel
        import xml.etree.ElementTree as ET
        tree = ET.parse(log_spec_path)
        root = tree.getroot()
        LoggingSpecification = root.find('{http://www.ni.com/VeriStand.Screen.SupportingDocuments}LoggingSpecification')
        self.__LoggingConfigurationModel = LoggingSpecification.find('{http://www.ni.com/VeriStand.Screen.SupportingDocuments}LoggingConfigurationModel')

        #Load configured channels information
        self.__Load_Channels()

        #Load rate
        self.__Load_Rate()

        #..Continue adding more functions to load more parameters as required

    def __Load_Channels(self):
        self.channels_list = []     #channels_list will be a list of dictionaries
        #For each channel on the loggin spec file
        for channel in self.__LoggingConfigurationModel.findall('{http://www.ni.com/VeriStand}LogChannelModel'):
            new_channel_dict = {'ChannelName':channel.get('ChannelName')[8:], 'ChannelPath':channel.get('ChannelPath')[8:], 'Group':channel.get('Group')[8:]}
            self.channels_list.append(new_channel_dict)

    def __Load_Rate(self):
        self.custom_rate = float(self.__LoggingConfigurationModel.get('CustomRate')[8:])

class logger:
    def __init__(self,gateway_IPAddress,log_path,channels):
        #Open Data Logging Manager Reference to gateway
        self.__Data_Logging_Manager_Ref = Factory().GetIDataLogging(gateway_IPAddress)

        #Create and configure TDMS file with channels
        self.__TDMSLogFile_Ref = TdmsLogFile(log_path,0)
        self.__add_channels(channels)

        #Create data logging specification with these settings
        self.__Logging_Specification_Ref = DataLoggingSpecification(self.__TDMSLogFile_Ref)

        #Assing default trigger (Start Immediately, do not wait for any trigger)
        self.__trigger = DefaultTrigger(True)
        self.__Logging_Specification_Ref.StartTrigger = self.__trigger

    def __add_channels(self,channels):
        #Add each of the channels to the file
        for channel in channels:
            #Obtain reference to group, create if it didn't exist
            Group_ref = self.__TDMSLogFile_Ref.GetChannelGroup(channel.get('Group'))
            if(Group_ref == None):
                #Creating group since it didn't exist
                Group_ref = TdmsChannelGroup(channel.get('Group'))

            #Create channel
            Channel_ref = TdmsChannel(channel.get('ChannelName'),channel.get('ChannelPath'))

            #Add channel to group
            Group_ref.AddChannel(Channel_ref)
        
            #Add group to TDMS file
            self.__TDMSLogFile_Ref.AddChannelGroup(Group_ref)

    def set_rate(self,rate):
        #Configure custom logging rate
        self.__Logging_Specification_Ref.LogDataAtTargetRate = False
        self.__Logging_Specification_Ref.CustomRate = rate

    def set_analog_trigger(self,trigger_channel, threshold, edge,strict_edge,PreTriggerDuration,Retriggerable,SegmentFileOnTrigger):
        #(Trigger channel, threshold, edge: rising 0 and falling 1,strict edge bool)
        self.__trigger = AnalogEdgeTrigger(trigger_channel,threshold,edge,strict_edge)

        #Assign trigger to spec
        self.__Logging_Specification_Ref.StartTrigger = self.__trigger

        #Set Pre-trigger duration, retriggerable flag and file segmenting if desired
        self.__Logging_Specification_Ref.PreTriggerDuration = 1
        self.__Logging_Specification_Ref.Retriggerable = True
        self.__Logging_Specification_Ref.SegmentFileOnTrigger = True

    def set_stop_trigger(self,PostTriggerDuration):
        #Set Stop Trigger (Duration)
        self.__Logging_Specification_Ref.StopTrigger = DefaultTrigger(True)
        self.__Logging_Specification_Ref.PostTriggerDuration = PostTriggerDuration

    def start(self,session_name):
        #Start Data Logging Session
        self.__Data_Logging_Manager_Ref.StartDataLoggingSession(session_name,self.__Logging_Specification_Ref)

    def stop(self,session_name):
        #Stop Data Logging Session
        logs_array = ["logs"]
        self.__Data_Logging_Manager_Ref.StopDataLoggingSession(session_name,True,Array[str](logs_array))

