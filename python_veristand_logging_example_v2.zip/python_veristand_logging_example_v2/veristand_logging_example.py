#from niveristand import nivs_rt_sequence, NivsParam, realtimesequencetools
#Import the next two elements to be able to read/write VeriStand channels and wait
from niveristand.clientapi import BooleanValue, ChannelReference, DoubleValue
from niveristand.library import wait

#Import the next elements to be able to create a logging specification
from veristand_logging import *

from os import path

file_path = path.join(path.dirname(path.abspath(__file__)), 'Logs\myLog.tdms')


###Setup logging ###

#Load information from existing logging specification file.
#*Current implementation only loads the channels and rate
logging_spec = Logging_Spec_File(path.join(path.dirname(path.abspath(__file__)), 'Logging Specification - Engine Demo.nivslspec'))

#Initialize logger
#We use localhost because Gateway is in local computer
#Replace second input with desired path and files name
#Channels list is a list of dictionaries. Each dictionary has 3 elements: ChannelName, ChannelPath, Group
log = logger("localhost",file_path,logging_spec.channels_list)

#Configure custom rate
log.set_rate(logging_spec.custom_rate)

#Configure trigger
log.set_analog_trigger("Aliases/ActualRPM",2800,0,True,1,True,True)

#Set log to stop after 4 seconds of trigger
log.set_stop_trigger(4)

#Start logging session
log.start("myLoggingSession")

###Changes channel values, wait and reset ###

#Prepare values that will be assigned
engine_power = BooleanValue(True)
desired_rpm = DoubleValue(3000)
wait_time = DoubleValue(10)

# You can access a channel with a ChannelReference
engine_power_chan = ChannelReference('Aliases/EnginePower')
desired_rpm_chan = ChannelReference('Aliases/DesiredRPM')
engine_power_chan.value = engine_power.value
desired_rpm_chan.value = desired_rpm.value
wait(wait_time.value)
engine_power_chan.value = False
desired_rpm_chan.value = 0

######

#Stop Logging session
log.stop("myLoggingSession")
